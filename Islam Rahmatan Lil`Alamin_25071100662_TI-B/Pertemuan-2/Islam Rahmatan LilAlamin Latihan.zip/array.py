cars = ["Ford", "Volvo", "BMW"] 
x = cars[0] 
cars[0] = "Toyota" 
x = len(cars)
if IndexError