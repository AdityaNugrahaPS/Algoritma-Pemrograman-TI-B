from MyModul import sapa

sapa("ilyas")