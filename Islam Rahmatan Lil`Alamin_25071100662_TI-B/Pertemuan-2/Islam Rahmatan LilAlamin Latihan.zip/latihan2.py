import myMath as my 

print(my.tambah(2,5))
print(my.fibbonaci(5))