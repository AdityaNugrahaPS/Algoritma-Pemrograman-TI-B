for i in range(10):
  print(i)


print(list(range(5)))
print(list(range(1, 6)))
print(list(range(5, 20, 3)))

r = range(10)
print(r[2])
print(r[:3])